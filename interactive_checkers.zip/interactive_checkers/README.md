# cs3110-project
Final project for CS 3110 at Cornell University.
Team members: Julia Ludwig (jal545), Claire Yun (cly29), Diego Fernandez (df356), Natalia Jordan (naj46)
